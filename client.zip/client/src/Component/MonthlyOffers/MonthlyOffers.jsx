import React from 'react'

function MonthlyOffers() {
  return (
    <div className='flex gap-3 mt-[20px] justify-center'>
        <div className='w-[300px] bg-slate-600 h-[450px] rounded-md'></div>
        <div className='w-[300px] bg-slate-600 h-[450px] rounded-md'></div>
        <div className='w-[300px] bg-slate-600 h-[450px] rounded-md'></div>
    </div>
  )
}

export default MonthlyOffers