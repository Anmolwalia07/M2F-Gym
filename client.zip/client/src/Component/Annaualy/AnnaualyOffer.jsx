import React from 'react'

function AnnaualyOffer() {
  return (
    <div className='flex gap-2 mt-[20px]'>
        <div className='w-[300px] bg-slate-600 h-[450px]'></div>
        <div className='w-[300px] bg-slate-600 h-[450px]'></div>
        <div className='w-[300px] bg-slate-600 h-[450px]'></div>
    </div>
  )
}

export default AnnaualyOffer