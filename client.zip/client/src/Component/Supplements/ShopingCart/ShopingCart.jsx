import React from 'react'

function ShopingCart() {
  return (
    <div className='w-[400px] h-[420px] bg-red-400 absolute bottom-0 right-0 m-[10px]'></div>
  )
}

export default ShopingCart